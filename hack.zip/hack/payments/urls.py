from django.urls import path
from .views import menu

urlpatterns = [
    path('info/',menu, name='news-list'),
    # path('upload/', upload_news, name='upload-news'),
]