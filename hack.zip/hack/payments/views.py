from django.shortcuts import render
def menu(request):
    return render(request, 'menu.html')

# Create your views here.
