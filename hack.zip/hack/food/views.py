# myapp/views.py
import requests
from django.shortcuts import render


# import requests
# from django.http import HttpResponse
# from django.shortcuts import render

# def product_detail(request, barcode):
#     # Replace these with your actual proxy details
#     proxy_host = "proxyserver.example.com"
#     proxy_port = "3128"
#     proxy_user = "9920"
#     proxy_pass = "1373"

#     proxies = {
#         "http": f"http://{proxy_user}:{proxy_pass}@{proxy_host}:{proxy_port}/",
#         "https": f"https://{proxy_user}:{proxy_pass}@{proxy_host}:{proxy_port}/",
#     }

#     url = f"https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
#     try:
#         response = requests.get(url, proxies=proxies)
#         if response.status_code == 200:
#             product_data = response.json().get('product', {})
#             return render(request, 'product_detail.html', {'product': product_data})
#         else:
#             return HttpResponse("Product not found", status=404)
#     except requests.exceptions.RequestException as e:
#         return HttpResponse(f"An error occurred: {e}", status=500)

# # def test_proxy():
# #     # Replace the below proxy configuration with your actual proxy details
# #     proxies = {
# #         "http": "http://9920:1373@proxyserver:3128",
# #         "https": "http://9920:1373@proxyserver:3128",
# #     }

# #     # Using httpbin to test the proxy
# #     test_url = "https://httpbin.org/ip"

# #     try:
#         response = requests.get(test_url, proxies=proxies)
#         if response.status_code == 200:
#             print("Proxy Test Successful. Response:", response.text)
#         else:
#             print("Proxy Test Failed. Status Code:", response.status_code)
#     except Exception as e:
#         print("An error occurred:", e)

# # Call the function to test the proxy
# test_proxy()

import requests
from django.http import HttpResponse
from django.shortcuts import render

def product_detail(request, barcode):
    url = f"https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            product_data = response.json().get('product', {})
            return render(request, 'product_detail.html', {'product': product_data})
        else:
            return HttpResponse("Product not found", status=404)
    except requests.exceptions.RequestException as e:
        return HttpResponse(f"An error occurred: {e}", status=500)
    
    
from django.http import HttpResponse

def product_detail(request, barcode):
    return HttpResponse("This is a test response.")


import requests
from django.http import HttpResponse
import logging

logger = logging.getLogger(__name__)

def product_detail(request, barcode):
    try:
        url = f"https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
        response = requests.get(url)
        if response.status_code == 200:
            product_data = response.json().get('product', {})
            return HttpResponse("Product data fetched successfully.")
        else:
            logger.error(f"Failed to fetch product data. Status code: {response.status_code}")
            return HttpResponse("Failed to fetch product data.")
    except Exception as e:
        logger.exception("Failed to fetch product data.")
        return HttpResponse("An error occurred.")

    
