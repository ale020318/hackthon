from django.urls import path
from . import views

urlpatterns = [
    path('submit/', views.submit_complaint, name='submit_complaint'),
    path('thank-you/', views.complaint_thank_you, name='complaint_thank_you'),
    path('list/', views.complaints_list, name='complaints_list')
]