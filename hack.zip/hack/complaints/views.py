from django.shortcuts import render, redirect
from .forms import ComplaintForm
from .models import Complaint


def submit_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('complaint_thank_you')
    else:
        form = ComplaintForm()
    return render(request, 'submit_complaint.html', {'form': form})

def complaint_thank_you(request):
    return render(request, 'complaint_thank_you.html')

def complaints_list(request):
    complaints = Complaint.objects.all().order_by('-created_at')  # Retrieves all complaints, newest first
    return render(request, 'complaints_list.html', {'complaints': complaints})

