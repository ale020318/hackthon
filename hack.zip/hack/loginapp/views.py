from django.shortcuts import render, redirect
from django.http import HttpResponse

def login_page(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if username == "admin" and password == "admin":
            return redirect('home')
        else:
            return HttpResponse("Invalid credentials")

    return render(request, 'loginapp.html')

def home(request):
    return render(request, 'home2.html')
