from django.contrib import admin
from .models import Profile
from django.contrib import admin
from .models import Product , ProductImage

admin.site.register(Profile)


admin.site.register(Product)

@admin.register(ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    list_display = ['product', 'image']
