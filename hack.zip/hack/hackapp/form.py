from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django import forms
from .models import Product
from django import forms
from .models import Product,ProductImage
from django import forms

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        
class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'company_name', 'price', 'category', 'launch_date']
        widgets = {
            'launch_date': forms.DateInput(attrs={'type': 'date'}),
            'price': forms.NumberInput(),
        }

class ProductImageForm(forms.ModelForm):
    class Meta:
        model = ProductImage
        fields = ['image']
        widgets = {
            'image': forms.FileInput(),  # Ensure no 'attrs={'multiple': True}' here
        }
        


class ChatForm(forms.Form):
    message = forms.CharField(label='Your Message', max_length=1000)
        