from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .form import UserRegisterForm
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .form import ProductForm
from .models import Product
import io
from reportlab.pdfgen import canvas
from django.shortcuts import render, redirect
from .form import ProductForm, ProductImageForm
from .models import Product, ProductImage
from django.shortcuts import render, redirect
from .form import ProductForm, ProductImageForm
from .models import Product, ProductImage
from reportlab.lib.pagesizes import letter
from reportlab.platypus import Image
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import dialogflow_v2 as dialogflow
import json
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import dialogflow_v2 as dialogflow
import json
import os
from django.shortcuts import render, redirect
from django.http import HttpResponse




def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

# def product_create_view(request):
#     if request.method == 'POST':
#         form = ProductForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('product_pdf', pk=form.instance.pk)
#     else:
#         form = ProductForm()
#     return render(request, 'product_form.html', {'form': form})

def product_pdf(request, pk):
    product = Product.objects.get(pk=pk)
    product_images = ProductImage.objects.filter(product=product)  # Assuming one-to-many relationship

    # Create PDF
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter  # Get the dimensions of the page for dynamic positioning if needed

    # Text information
    p.drawString(100, 800, f"Name: {product.name}")
    p.drawString(100, 780, f"Company Name: {product.company_name}")
    p.drawString(100, 760, f"Price: {product.price}")
    p.drawString(100, 740, f"Category: {product.category}")
    p.drawString(100, 720, f"Launch Date: {product.launch_date}")

    # Image (assuming there is at least one image)
    if product_images.exists():
        image_path = product_images.first().image.path  # Gets the path of the first image
        img = Image(image_path, width=2, height=2)  # Set desired size, e.g., 2 inches by 2 inches
        img.drawOn(p, 100, 620)  # Position where you want the image to be placed

    p.showPage()
    p.save()

    buffer.seek(0)
    return HttpResponse(buffer, content_type='application/pdf')


# def product_create_view(request):
#     if request.method == 'POST':
#         form = ProductForm(request.POST, request.FILES)
#         if form.is_valid():
#             new_product = form.save()
#             image = request.FILES.get('image')  # Adjust 'image' to match your HTML input's name attribute for the file upload
            
#             if image:  # Check if there is an image uploaded
#                 ProductImage.objects.create(product=new_product, image=image)
            
#             return redirect('product_pdf', pk=new_product.pk)  # Assuming you have a view to generate a PDF for the product
#     else:
#         form = ProductForm()
    
#     return render(request, 'product_form.html', {'form': form})

def product_create_view(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        images = request.FILES.getlist('images')  # This matches the 'name' attribute in your HTML input
        if form.is_valid():
            new_product = form.save()
            for image in images:  # Loop through the images
                ProductImage.objects.create(product=new_product, image=image)
            return redirect('product_pdf', pk=new_product.pk)  # Assuming you have a URL named 'product_pdf'
    else:
        form = ProductForm()
    
    return render(request, 'product_form.html', {'form': form})




