from django.urls import path
from . import views
from .views import product_create_view, product_pdf
from django.conf.urls.static import static
from django.conf import settings
from django.urls import path
from django.contrib import admin
from django.urls import path, include 
  


urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('new/', product_create_view, name='product_new'),
    path('pdf/<int:pk>/', product_pdf, name='product_pdf'),
   # path('', include('loginapp.urls')),
    #path('chat/', chat_view, name='chat'),

    
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
