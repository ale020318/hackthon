from django.shortcuts import render, redirect
from .models import Notice
from .forms import NoticeForm



def notice_list(request):
    notices = Notice.objects.all().order_by('-date_of_issue')
    return render(request, 'notice_list.html', {'notices': notices})

def add_notice(request):
    if request.method == 'POST':
        form = NoticeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('notice_list')
    else:
        form = NoticeForm()
    return render(request, 'add_notice.html', {'form': form})
