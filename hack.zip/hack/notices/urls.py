from django.urls import path
from .views import notice_list, add_notice

urlpatterns = [
    path('notices/', notice_list, name='notice_list'),
    path('add/', add_notice, name='add_notice'),
]
