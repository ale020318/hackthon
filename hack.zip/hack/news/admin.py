from django.contrib import admin
from .models import News

class NewsAdmin(admin.ModelAdmin):
    list_display = ('title', 'date_posted')  # Customize the display list
    list_filter = ('date_posted',)  # Enable filtering by date_posted
    search_fields = ('title', 'content')  # Enable search by title and content

admin.site.register(News, NewsAdmin)
