from django.urls import path
from .views import news_list, upload_news

urlpatterns = [
    path('', news_list, name='news-list'),
    path('upload/', upload_news, name='upload-news'),
]
