from django.shortcuts import render, redirect
from .models import News
from .forms import NewsForm

def news_list(request):
    news = News.objects.all().order_by('-date_posted')
    return render(request, 'news_list.html', {'news': news})

def upload_news(request):
    if request.method == 'POST':
        form = NewsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('news-list')
    else:
        form = NewsForm()
    return render(request, 'upload_news.html', {'form': form})
